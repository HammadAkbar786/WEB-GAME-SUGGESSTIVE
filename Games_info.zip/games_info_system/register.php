<?php require_once 'functions.php'; ?>
<?php include 'header.php'; ?>
    <div class="main container">
        <?php if(isset($_SESSION['success'])): ?>
            <div class="alert alert-success text-center"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); endif; ?>
        <?php if(isset($_SESSION['error'])): ?>
            <div class="alert alert-danger text-center"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); endif; ?>
        <form action="" class="za-form" method="POST">
            <input class="form-inp" type="text" name="name" placeholder="Name" />
            <input class="form-inp" type="email" name="email" placeholder="Email address" />
            <input class="form-inp" type="password" name="password" placeholder="Password" />
            <input class="form-submit" name="register_user" type="submit" value="Signup">
        </form>
    </div>

<?php include 'footer.php' ?>