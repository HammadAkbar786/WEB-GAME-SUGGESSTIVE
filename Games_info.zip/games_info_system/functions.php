<?php

session_start();


 function preview($data){
     echo "<pre>";
     print_r($data);
     exit;
 }

 function get_slug(){
    $url = explode('/',$_SERVER['REQUEST_URI']);
    $url = $url[count($url) - 1];
    $url = explode('.', $url);
    $url = $url[0];
    return $url;
 }


 if(isset($_POST['register_user'])){
     $name = $_POST['name'];
     $email = $_POST['email'];
     $password = $_POST['password'];

     if(!file_exists('./data/users.json')){
         file_put_contents('./data/users.json', []);
     }

     if(file_exists('./data/users.json')){
        $users = json_decode(file_get_contents('./data/users.json'));
        $data = [
            'name' => $name,
            'email' => $email,
            'password' => md5($password)
        ];

        foreach($users as $user){
            if($user->email == $email){
                $_SESSION['error'] = 'Email already exists';
                header('location: register.php');
                exit;
            }
        }
        
        $users[] = $data;
        file_put_contents('./data/users.json', json_encode($users));
        $_SESSION['success'] = 'User signed up successfully';
        header('location: register.php');exit;
     }
 }


 if(isset($_POST['login'])){
     $email = $_POST['email'];
     $password = $_POST['password'];

     $users = json_decode(file_get_contents('./data/users.json'));

     foreach($users as $user){
         if($user->email == $email && md5($password) == $user->password){
             $_SESSION['is_logged_in'] = true;
             $_SESSION['user'] = $user;
             header('location: index.php');
             exit;
         }
     }

     $_SESSION['error'] = "Invalid credentials";
     header('location: login.php');
     exit;

 }


