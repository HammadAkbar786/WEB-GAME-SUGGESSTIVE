<?php require_once 'functions.php'; ?>
<?php include 'header.php'; ?>
    
    <div class="main container">
        <div class="hero-container">
            <h1 class="hero_title">GameX</h1>
            <p class="hero_desc">Get the reviews of the games for better experience</p>
            <div class="cta">
                <a href="games.php" class="btn-solid">Explore</a>
                <?php if(!isset($_SESSION['is_logged_in'])): ?>
                <a href="login.php" class="btn-outline">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
   

<?php include 'footer.php' ?>