<?php require_once 'functions.php'; ?>
<?php

    $games = json_decode(file_get_contents('./data/games.json'));
    // preview($games);

?>
<?php include 'header.php'; ?>
    <div class="main container">
        <div class="row">
            <?php if($games): foreach($games as $key => $game): ?>
                <div class="col-md-3 col-sm-6">
                    <div class="game-card">
                        <div class="header">
                            <img src="<?= $game->img ?>" alt="" class="game-img">
                        </div>
                        <div class="body">
                            <h2 class="game-title"><?= $game->title ?></h2>
                            <p class="game-desc"><?= mb_substr($game->description, 0, 100) ?>...</p>
                        </div>
                        <div class="footer">
                            <a href="game_details.php?id=<?= $key ?>" class="game-details">Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>

<?php include 'footer.php' ?>