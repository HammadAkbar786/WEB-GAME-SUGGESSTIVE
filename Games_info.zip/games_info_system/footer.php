
<footer class="za-footer">
    <div class="footer-links">
      <a href="index.php">Home</a>
      <a href="games.php">Games</a>
      <a href="about.php">About</a>
      <a href="register.php">Register</a>
    </div>
    <div class="footer-social">
      <a href="#"><i class="fa-brands fa-facebook"></i></a>
      <a href="#"><i class="fa-brands fa-twitter"></i></a>
      <a href="#"><i class="fa-brands fa-instagram"></i></a>
    </div>
</footer>

</div>
<!-- Container end -->



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="./assets/js/jquery.star-rating.js"></script>
    <script src="./assets/js/script.js"></script>
  </body>
</html>