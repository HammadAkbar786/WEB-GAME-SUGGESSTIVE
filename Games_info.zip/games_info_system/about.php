<?php require_once 'functions.php'; ?>
<?php include 'header.php'; ?>
    <div class="container main about-section">
        <h1>About</h1>
        <p>The Xbox has an extensive library of games that can satisfy gamers of all ages. These include AAA blockbuster adventures or charming little indie darlings that can teach us meaningful life lessons. And if a child somehow comes across a violent title without your notice, you can use the Xbox's parental controls to protect them. However, since there are so many video games to choose from it can be difficult as a parent to determine which game is right for your kid. But don't worry, we're here to help.</p>
        <p>We have rounded up all the best Xbox games you can buy for kids of any age in 2021. While most of our picks cater to younger children, we have included some titles for the older kids. These are family-friendly joyrides that prove that video games can be made for everyone. Here are the best kids games for Xbox One, Xbox Series X, Xbox Series S, PC, and Xbox Cloud Gaming.</p>
        <p>What's great about the Xbox's huge library of games is that many of the most popular games are non-violent and appropriate for children. Not to mention many of the best games on Xbox are available at cheap prices on Xbox Game Pass. So if you have a subscription, you can take advantage of the best deals on Xbox Game Pass for your kid's gaming experience.</p>
    </div>

<?php include 'footer.php' ?>