<?php require_once 'functions.php'; ?>

<?php

    if(!isset($_GET['id'])){
        header('location: games.php');
    }

    $all_games = json_decode(file_get_contents('./data/games.json'));
    $game = $all_games[$_GET['id']];

?>

<?php include 'header.php'; ?>
    
    <div class="main container">
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <img src="<?= $game->img ?>" alt="" class="game-detail-img" style="width: 100%" >
                <div class="rating" style="margin-top: 20px"></div>
            </div>
            <div class="col-md-8 col-sm-12">
                <h2><?= $game->title ?></h2>
                <p><?= $game->description ?></p>
            </div>
        </div>
    </div>
   

<?php include 'footer.php' ?>

<script>
    $(document).ready(function() {
        $('.rating i[data-index=<?= $game->rating - 1 ?>]').click();
    })
</script>