$(document).ready(function () {
  $(".rating").starRating({
    showInfo: false,
    initialRating: 4,
  });
});
