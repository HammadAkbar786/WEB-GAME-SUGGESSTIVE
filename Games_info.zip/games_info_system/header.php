<?php 

  if(isset($_SESSION['is_logged_in'])){
    $user = $_SESSION['user'];
  }

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GameX | Game reviews</title>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="./assets/css/style.css" />
  </head>
  <body>
    <!-- Container Start  -->
  <div class="bg-gradient-dark za-container za-home">
  <header class="za-header">
    <div class="left">
      <div class="logo">
        <h2>GameX</h2>
      </div>
    </div>
    <div class="right">
      <ul class="za-nav">
        <li class="nav"><a href="index.php" class="link <?= (get_slug() == 'index' ? 'active' : '') ?>">Home</a></li>
        <li class="nav"><a href="about.php" class="link <?= (get_slug() == 'about' ? 'active' : '') ?>">About</a></li>
        <li class="nav"><a href="games.php" class="link <?= (get_slug() == 'games' ? 'active' : '') ?>">Games</a></li>
        <li class="nav"><a href="contact.php" class="link <?= (get_slug() == 'contact' ? 'active' : '') ?>">Contact</a></li>
        <?php if(!isset($_SESSION['is_logged_in'])){ ?>
        <li class="nav"><a href="login.php" class="link">Login</a></li>
        <li class="nav"><a href="register.php" class="link">Register</a></li>
        <?php }else{ ?>
          <li class="nav"><a href="logout.php" class="link">logout</a></li>
          <li class="nav"><a href="javascript:void(0)" class="link">Welcome, <?= $user->name ?></a></li>
        <?php } ?>
      </ul>
    </div>
  </header>