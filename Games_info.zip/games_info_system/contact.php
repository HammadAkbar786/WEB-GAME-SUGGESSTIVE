<?php require_once 'functions.php'; ?>
<?php include 'header.php'; ?>
    <div class="main container">
        <form action="" class="za-form" method="POST">
            <input class="form-inp" type="text" name="name" placeholder="Full Name" />
            <input class="form-inp" type="email" name="email" placeholder="Email address" />
            <textarea name="message" id="" cols="30" rows="10" class="form-inp"></textarea>
            <input class="form-submit" name="register_user" type="submit" value="Signup">
        </form>
    </div>

<?php include 'footer.php' ?>